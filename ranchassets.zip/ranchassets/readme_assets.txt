The assets and maps listed here are granted by the download author for reference and personal use only.
Credit must be given to all listed authors and you need to ask for permission before distributing them in any way.

pl_ranch and associated names.

Includes the following resource team:

Switchgeer
https://tf2maps.net/members/switchgeer.31775/
Orizyre
https://tf2maps.net/members/orizyre.43022/
Bestest bread
https://tf2maps.net/members/bestest-bread-is-lost-ish.40428/
MayaMogus
https://tf2maps.net/members/mayamogus.41180/
juansanchez0392
https://tf2maps.net/members/juansanchez0392.42338/
Rapoza Dynamica
https://tf2maps.net/members/rapoza-dynamica.43965/

koth_rainfall_b1_ori1_dog1_bread0.vmf

Includes the following resource team:

Bestest bread
https://tf2maps.net/members/bestest-bread-is-lost-ish.40428/
dogburg
https://tf2maps.net/members/dogburg.41019/
Orizyre
https://tf2maps.net/members/orizyre.43022/
Tiftid
https://tf2maps.net/members/tiftid.24946/


koth_pitfall_final1a.vmf and associated names.

Includes the following resource team:

Bestest bread 
https://tf2maps.net/members/bestest-bread-is-lost-ish.40428/
Blear
https://tf2maps.net/members/blear.44811/
juansanchez0392
https://tf2maps.net/members/juansanchez0392.42338/
MayaMogus
https://tf2maps.net/members/mayamogus.41180/
Orizyre
https://tf2maps.net/members/orizyre.43022/
Tiftid
https://tf2maps.net/members/tiftid.24946/



